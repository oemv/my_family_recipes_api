import express from "express";
import multer from "multer";
import * as auth from '../services/auth';
import { USER_IMAGES_FOLDER } from '../constants';

let router = express.Router();
let storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, USER_IMAGES_FOLDER)
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + '-foo' );
  }
})
let upload = multer({ storage: storage });

export default function (){   	
	
    router.get('/picture', auth.isAuthenticated, (req, res)=>{
    		res.render('profile/picture', {user: req.user});	
    });	
    
		router.post('/picture', auth.isAuthenticated, upload.single('display_image'), (req, res)=>{
    		res.render('home', {user: req.user});
    });
    
    return router;
}