import express from 'express';
import morgan from 'morgan';
import path from 'path';
import cookieParser from 'cookie-parser';
import bodyParser from 'body-parser';
import http from 'http';
import passport from 'passport';
import expressSession from 'express-session';
import flash from 'connect-flash';

import * as DB from './services/db';
import * as auth from './services/auth';
import { SESSION_SECRET, SESSION_KEY } from './constants';
import authController from './controllers/auth';
import profileController from './controllers/profile';

DB.connect(DB.MODE_DEV,()=>{
    console.log("Connected to the database");
});
auth.init();

let app = express();
app.set('views', path.join( __dirname , '..' , 'server' , 'views' ));
app.set('view engine' , 'jade');

app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(express.static(path.join(__dirname,'..', 'public')));
app.use(expressSession({secret: SESSION_SECRET, key: SESSION_KEY})); //pass this from the process?
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
app.use('/', authController(passport));
app.use('/profile', profileController());

app.use(function(req, res, next) {
    let err = new Error('Not Found');
    err.status = 404;
    next(err);
});

app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: err
    });
});

app.listen(3000, function () {
    console.log('Example app listening on port 3000!');
});